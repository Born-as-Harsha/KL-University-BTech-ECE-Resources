Version 4
SymbolType BLOCK
LINE Normal -48 -32 -48 -48
LINE Normal -63 -16 -96 -16
LINE Normal 16 -16 48 -16
LINE Normal 16 0 48 0
RECTANGLE Normal 17 16 -63 -32
TEXT -57 6 Left 1 SRAM0W
TEXT -52 -27 Left 0 vdd
TEXT -58 -6 VLeft 0 wl
TEXT 6 -16 Left 0 Q
PIN -48 -48 NONE 8
PINATTR PinName vdd
PINATTR SpiceOrder 1
PIN -96 -16 NONE 8
PINATTR PinName wl
PINATTR SpiceOrder 2
PIN 48 -16 NONE 8
PINATTR PinName Q
PINATTR SpiceOrder 3
PIN 48 0 NONE 8
PINATTR PinName Qbar
PINATTR SpiceOrder 4
