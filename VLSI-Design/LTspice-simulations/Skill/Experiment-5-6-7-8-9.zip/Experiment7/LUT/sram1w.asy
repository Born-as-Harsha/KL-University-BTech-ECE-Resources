Version 4
SymbolType BLOCK
LINE Normal -48 -16 -112 -16
LINE Normal -32 -32 -32 -48
LINE Normal 48 -16 64 -16
LINE Normal 64 0 48 0
RECTANGLE Normal 49 16 -48 -32
TEXT -33 -9 Left 1 SRAM1W
TEXT -45 -8 VTop 0 wl
TEXT -37 -26 Left 0 vdd
TEXT 38 -24 Left 0 Q
PIN -112 -16 NONE 8
PINATTR PinName wl
PINATTR SpiceOrder 1
PIN -32 -48 NONE 8
PINATTR PinName vdd
PINATTR SpiceOrder 2
PIN 64 -16 NONE 8
PINATTR PinName Q
PINATTR SpiceOrder 3
PIN 64 0 NONE 8
PINATTR PinName Qbar
PINATTR SpiceOrder 4
