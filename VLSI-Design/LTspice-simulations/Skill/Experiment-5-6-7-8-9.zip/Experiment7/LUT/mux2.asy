Version 4
SymbolType BLOCK
LINE Normal -62 -64 -113 -64
LINE Normal -63 -32 -112 -32
LINE Normal -48 -79 -49 -97
LINE Normal -31 2 -31 16
LINE Normal -17 -48 32 -49
RECTANGLE Normal -16 1 -63 -80
TEXT -39 -17 VLeft 1 MUX2
TEXT -53 -75 Left 0 vdd
TEXT -33 -8 Left 0 S
TEXT -24 -46 VLeft 0 Y
PIN -48 -96 NONE 8
PINATTR PinName vdd
PINATTR SpiceOrder 3
PIN -32 16 NONE 8
PINATTR PinName S
PINATTR SpiceOrder 4
PIN 32 -48 NONE 8
PINATTR PinName Y
PINATTR SpiceOrder 5
PIN -112 -64 NONE 8
PINATTR PinName I2
PINATTR SpiceOrder 1
PIN -112 -32 NONE 8
PINATTR PinName I1
PINATTR SpiceOrder 2
